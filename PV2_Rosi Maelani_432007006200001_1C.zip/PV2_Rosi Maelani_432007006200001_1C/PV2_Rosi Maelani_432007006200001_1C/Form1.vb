﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CmbJenis.Items.Add("Seafood")
        CmbJenis.Items.Add("Ayam")
        CmbJenis.Items.Add("Ikan")
        CmbJenis.Items.Add("Berkuah")
    End Sub

    Private Sub CmbJenis_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbJenis.SelectedIndexChanged
        If CmbJenis.Text = "Seafood" Then
            CmbNama.Items.Clear()
            CmbNama.Text = ""
            CmbNama.Items.Add("Kerang")
            CmbNama.Items.Add("Kepiting")
            CmbNama.Items.Add("Cumi-Cumi")
            CmbNama.Items.Add("Gurita")
            CmbNama.Items.Add("Lobster")

        ElseIf CmbJenis.Text = "Ayam" Then
            CmbNama.Items.Clear()
            CmbNama.Text = ""
            CmbNama.Items.Add("Ayam Goreng")
            CmbNama.Items.Add("Ayam Bakar")
            CmbNama.Items.Add("Ayam Pedas Manis")
            CmbNama.Items.Add("Ayam Saus Tiram")
            CmbNama.Items.Add("Ayam Geprek")

        ElseIf CmbJenis.Text = "Ikan" Then
            CmbNama.Items.Clear()
            CmbNama.Text = ""
            CmbNama.Items.Add("Ikan Goreng")
            CmbNama.Items.Add("Ikan Bakar")
            CmbNama.Items.Add("Ikan Kuah Kuning")
            CmbNama.Items.Add("Ikan Bumbu Balado")
            CmbNama.Items.Add("Sop Ikan Patin")

        ElseIf CmbJenis.Text = "Berkuah" Then
            CmbNama.Items.Clear()
            CmbNama.Text = ""
            CmbNama.Items.Add("Bakso")
            CmbNama.Items.Add("Soto")
            CmbNama.Items.Add("Rawon")
            CmbNama.Items.Add("Sop Buntut")
            CmbNama.Items.Add("Sayur Lodeh")
        End If
    End Sub

    Private Sub CmbNama_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbNama.SelectedIndexChanged
        Dim Nm_Makanan As String
        Nm_Makanan = CmbNama.Text
        Select Case (Nm_Makanan)
            Case "Kerang"
                TxtHarga.Text = 60000
            Case "Kepiting"
                TxtHarga.Text = 50000
            Case "Cumi-Cumi"
                TxtHarga.Text = 65000
            Case "Gurita"
                TxtHarga.Text = 80000
            Case "Lobster"
                TxtHarga.Text = 100000
            Case "Ayam Goreng"
                TxtHarga.Text = 40000
            Case "Ayam Bakar"
                TxtHarga.Text = 50000
            Case "Ayam Pedas Manis"
                TxtHarga.Text = 55000
            Case "Ayam Saus Tiram"
                TxtHarga.Text = 60000
            Case "Ayam Geprek"
                TxtHarga.Text = 45000
            Case "Ikan Goreng"
                TxtHarga.Text = 50000
            Case "Ikan Bakar"
                TxtHarga.Text = 65000
            Case "Ikan Kuah Kuning"
                TxtHarga.Text = 40000
            Case "Ikan Bumbu Balado"
                TxtHarga.Text = 45000
            Case "Sop Ikan Patin"
                TxtHarga.Text = 50000
            Case "Bakso"
                TxtHarga.Text = 25000
            Case "Soto"
                TxtHarga.Text = 23000
            Case "Rawon"
                TxtHarga.Text = 30000
            Case "Sop Buntut"
                TxtHarga.Text = 35000
            Case "Sayur Lodeh"
                TxtHarga.Text = 18000
        End Select
    End Sub

    Private Sub BtnHitung_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHitung.Click
        TxtTotal.Text = Val(TxtHarga.Text) * Val(TxtJmlBeli.Text)
        If TxtTotal.Text > 150000 Then
            TxtDiskon.Text = 5 / 100 * 150000
        Else
            TxtDiskon.Text = 0
        End If
        TxtTotalByr.Text = Val(TxtTotal.Text) - Val(TxtDiskon.Text)
    End Sub

    Private Sub BtnBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnBaru.Click
        CmbJenis.Text = ""
        CmbNama.Text = ""
        TxtHarga.Text = ""
        TxtJmlBeli.Text = ""
        TxtTotal.Text = ""
        TxtDiskon.Text = ""
        TxtTotalByr.Text = ""
    End Sub

    Private Sub BtnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnKeluar.Click
        Dim tanya
        tanya = MessageBox.Show("Anda yakin ingin keluar ?", "Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If tanya = vbYes Then
            Me.Close()
        End If
    End Sub

End Class
