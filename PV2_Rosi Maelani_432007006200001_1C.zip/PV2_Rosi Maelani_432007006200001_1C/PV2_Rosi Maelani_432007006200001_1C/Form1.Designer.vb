﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.LblJudul = New System.Windows.Forms.Label()
        Me.LblNama = New System.Windows.Forms.Label()
        Me.LblJenis = New System.Windows.Forms.Label()
        Me.LblHarga = New System.Windows.Forms.Label()
        Me.LblJmlBeli = New System.Windows.Forms.Label()
        Me.LblTotalharga = New System.Windows.Forms.Label()
        Me.LblDiskon = New System.Windows.Forms.Label()
        Me.LblTotalByr = New System.Windows.Forms.Label()
        Me.LblKet = New System.Windows.Forms.Label()
        Me.CmbNama = New System.Windows.Forms.ComboBox()
        Me.CmbJenis = New System.Windows.Forms.ComboBox()
        Me.TxtHarga = New System.Windows.Forms.TextBox()
        Me.TxtJmlBeli = New System.Windows.Forms.TextBox()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.TxtDiskon = New System.Windows.Forms.TextBox()
        Me.TxtTotalByr = New System.Windows.Forms.TextBox()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.BtnBaru = New System.Windows.Forms.Button()
        Me.LblByMe = New System.Windows.Forms.Label()
        Me.PicKepiting = New System.Windows.Forms.PictureBox()
        Me.PicAyam = New System.Windows.Forms.PictureBox()
        Me.PicBakso = New System.Windows.Forms.PictureBox()
        Me.PicIkan = New System.Windows.Forms.PictureBox()
        Me.GbMakanan = New System.Windows.Forms.GroupBox()
        Me.LblBakso = New System.Windows.Forms.Label()
        Me.LblIkan = New System.Windows.Forms.Label()
        Me.LblAyam = New System.Windows.Forms.Label()
        Me.LblKepiting = New System.Windows.Forms.Label()
        Me.GbPemesanan = New System.Windows.Forms.GroupBox()
        Me.GbPembayaran = New System.Windows.Forms.GroupBox()
        CType(Me.PicKepiting, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicAyam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBakso, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicIkan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbMakanan.SuspendLayout()
        Me.GbPemesanan.SuspendLayout()
        Me.GbPembayaran.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblJudul
        '
        Me.LblJudul.AutoSize = True
        Me.LblJudul.Font = New System.Drawing.Font("Gabriola", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudul.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblJudul.Location = New System.Drawing.Point(155, 0)
        Me.LblJudul.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblJudul.Name = "LblJudul"
        Me.LblJudul.Size = New System.Drawing.Size(346, 59)
        Me.LblJudul.TabIndex = 0
        Me.LblJudul.Text = "Aplikasi Pemesanan Makanan"
        Me.LblJudul.UseMnemonic = False
        '
        'LblNama
        '
        Me.LblNama.AutoSize = True
        Me.LblNama.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNama.Location = New System.Drawing.Point(11, 62)
        Me.LblNama.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblNama.Name = "LblNama"
        Me.LblNama.Size = New System.Drawing.Size(107, 19)
        Me.LblNama.TabIndex = 1
        Me.LblNama.Text = "Nama Makanan"
        '
        'LblJenis
        '
        Me.LblJenis.AutoSize = True
        Me.LblJenis.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJenis.Location = New System.Drawing.Point(11, 30)
        Me.LblJenis.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblJenis.Name = "LblJenis"
        Me.LblJenis.Size = New System.Drawing.Size(99, 19)
        Me.LblJenis.TabIndex = 2
        Me.LblJenis.Text = "Jenis Makanan"
        '
        'LblHarga
        '
        Me.LblHarga.AutoSize = True
        Me.LblHarga.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHarga.Location = New System.Drawing.Point(11, 94)
        Me.LblHarga.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblHarga.Name = "LblHarga"
        Me.LblHarga.Size = New System.Drawing.Size(90, 19)
        Me.LblHarga.TabIndex = 3
        Me.LblHarga.Text = "Harga / Porsi"
        '
        'LblJmlBeli
        '
        Me.LblJmlBeli.AutoSize = True
        Me.LblJmlBeli.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJmlBeli.Location = New System.Drawing.Point(11, 126)
        Me.LblJmlBeli.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblJmlBeli.Name = "LblJmlBeli"
        Me.LblJmlBeli.Size = New System.Drawing.Size(78, 19)
        Me.LblJmlBeli.TabIndex = 4
        Me.LblJmlBeli.Text = "Jumlah Beli"
        '
        'LblTotalharga
        '
        Me.LblTotalharga.AutoSize = True
        Me.LblTotalharga.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotalharga.Location = New System.Drawing.Point(11, 30)
        Me.LblTotalharga.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblTotalharga.Name = "LblTotalharga"
        Me.LblTotalharga.Size = New System.Drawing.Size(80, 19)
        Me.LblTotalharga.TabIndex = 5
        Me.LblTotalharga.Text = "Total Harga"
        '
        'LblDiskon
        '
        Me.LblDiskon.AutoSize = True
        Me.LblDiskon.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDiskon.Location = New System.Drawing.Point(11, 61)
        Me.LblDiskon.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblDiskon.Name = "LblDiskon"
        Me.LblDiskon.Size = New System.Drawing.Size(50, 19)
        Me.LblDiskon.TabIndex = 6
        Me.LblDiskon.Text = "Diskon"
        '
        'LblTotalByr
        '
        Me.LblTotalByr.AutoSize = True
        Me.LblTotalByr.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotalByr.Location = New System.Drawing.Point(11, 90)
        Me.LblTotalByr.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblTotalByr.Name = "LblTotalByr"
        Me.LblTotalByr.Size = New System.Drawing.Size(77, 19)
        Me.LblTotalByr.TabIndex = 7
        Me.LblTotalByr.Text = "Total Bayar"
        '
        'LblKet
        '
        Me.LblKet.AutoSize = True
        Me.LblKet.Font = New System.Drawing.Font("Goudy Old Style", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblKet.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblKet.Location = New System.Drawing.Point(25, 446)
        Me.LblKet.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblKet.Name = "LblKet"
        Me.LblKet.Size = New System.Drawing.Size(261, 15)
        Me.LblKet.TabIndex = 8
        Me.LblKet.Text = "Diskon 5% untuk total pembelian diatas Rp 150.000"
        '
        'CmbNama
        '
        Me.CmbNama.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.CmbNama.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbNama.FormattingEnabled = True
        Me.CmbNama.Location = New System.Drawing.Point(146, 62)
        Me.CmbNama.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CmbNama.Name = "CmbNama"
        Me.CmbNama.Size = New System.Drawing.Size(140, 25)
        Me.CmbNama.TabIndex = 9
        '
        'CmbJenis
        '
        Me.CmbJenis.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.CmbJenis.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbJenis.FormattingEnabled = True
        Me.CmbJenis.Location = New System.Drawing.Point(146, 30)
        Me.CmbJenis.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CmbJenis.Name = "CmbJenis"
        Me.CmbJenis.Size = New System.Drawing.Size(140, 25)
        Me.CmbJenis.TabIndex = 10
        '
        'TxtHarga
        '
        Me.TxtHarga.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.TxtHarga.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtHarga.Location = New System.Drawing.Point(146, 94)
        Me.TxtHarga.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TxtHarga.Name = "TxtHarga"
        Me.TxtHarga.Size = New System.Drawing.Size(140, 23)
        Me.TxtHarga.TabIndex = 11
        '
        'TxtJmlBeli
        '
        Me.TxtJmlBeli.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.TxtJmlBeli.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtJmlBeli.Location = New System.Drawing.Point(146, 124)
        Me.TxtJmlBeli.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TxtJmlBeli.Name = "TxtJmlBeli"
        Me.TxtJmlBeli.Size = New System.Drawing.Size(140, 23)
        Me.TxtJmlBeli.TabIndex = 12
        '
        'TxtTotal
        '
        Me.TxtTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.TxtTotal.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotal.Location = New System.Drawing.Point(127, 29)
        Me.TxtTotal.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(140, 23)
        Me.TxtTotal.TabIndex = 13
        '
        'TxtDiskon
        '
        Me.TxtDiskon.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.TxtDiskon.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDiskon.Location = New System.Drawing.Point(127, 59)
        Me.TxtDiskon.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TxtDiskon.Name = "TxtDiskon"
        Me.TxtDiskon.Size = New System.Drawing.Size(140, 23)
        Me.TxtDiskon.TabIndex = 14
        '
        'TxtTotalByr
        '
        Me.TxtTotalByr.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.TxtTotalByr.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotalByr.Location = New System.Drawing.Point(127, 90)
        Me.TxtTotalByr.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TxtTotalByr.Name = "TxtTotalByr"
        Me.TxtTotalByr.Size = New System.Drawing.Size(140, 23)
        Me.TxtTotalByr.TabIndex = 15
        '
        'BtnHitung
        '
        Me.BtnHitung.BackColor = System.Drawing.Color.FromArgb(CType(CType(139, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.BtnHitung.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHitung.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.BtnHitung.Location = New System.Drawing.Point(102, 475)
        Me.BtnHitung.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(134, 35)
        Me.BtnHitung.TabIndex = 16
        Me.BtnHitung.Text = "Hitung"
        Me.BtnHitung.UseVisualStyleBackColor = False
        '
        'BtnKeluar
        '
        Me.BtnKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(139, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.BtnKeluar.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnKeluar.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.BtnKeluar.Location = New System.Drawing.Point(557, 12)
        Me.BtnKeluar.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(65, 27)
        Me.BtnKeluar.TabIndex = 17
        Me.BtnKeluar.Text = "Close"
        Me.BtnKeluar.UseVisualStyleBackColor = False
        '
        'BtnBaru
        '
        Me.BtnBaru.BackColor = System.Drawing.Color.FromArgb(CType(CType(139, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.BtnBaru.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnBaru.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.BtnBaru.Location = New System.Drawing.Point(410, 417)
        Me.BtnBaru.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BtnBaru.Name = "BtnBaru"
        Me.BtnBaru.Size = New System.Drawing.Size(115, 33)
        Me.BtnBaru.TabIndex = 19
        Me.BtnBaru.Text = "New Order"
        Me.BtnBaru.UseVisualStyleBackColor = False
        '
        'LblByMe
        '
        Me.LblByMe.AutoSize = True
        Me.LblByMe.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblByMe.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblByMe.Location = New System.Drawing.Point(266, 43)
        Me.LblByMe.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblByMe.Name = "LblByMe"
        Me.LblByMe.Size = New System.Drawing.Size(106, 19)
        Me.LblByMe.TabIndex = 20
        Me.LblByMe.Text = "By Rosi Maelani"
        '
        'PicKepiting
        '
        Me.PicKepiting.Image = CType(resources.GetObject("PicKepiting.Image"), System.Drawing.Image)
        Me.PicKepiting.Location = New System.Drawing.Point(20, 32)
        Me.PicKepiting.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicKepiting.Name = "PicKepiting"
        Me.PicKepiting.Size = New System.Drawing.Size(122, 95)
        Me.PicKepiting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicKepiting.TabIndex = 21
        Me.PicKepiting.TabStop = False
        '
        'PicAyam
        '
        Me.PicAyam.Image = CType(resources.GetObject("PicAyam.Image"), System.Drawing.Image)
        Me.PicAyam.Location = New System.Drawing.Point(164, 32)
        Me.PicAyam.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicAyam.Name = "PicAyam"
        Me.PicAyam.Size = New System.Drawing.Size(121, 95)
        Me.PicAyam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicAyam.TabIndex = 22
        Me.PicAyam.TabStop = False
        '
        'PicBakso
        '
        Me.PicBakso.Image = CType(resources.GetObject("PicBakso.Image"), System.Drawing.Image)
        Me.PicBakso.Location = New System.Drawing.Point(449, 32)
        Me.PicBakso.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicBakso.Name = "PicBakso"
        Me.PicBakso.Size = New System.Drawing.Size(128, 95)
        Me.PicBakso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBakso.TabIndex = 23
        Me.PicBakso.TabStop = False
        '
        'PicIkan
        '
        Me.PicIkan.Image = CType(resources.GetObject("PicIkan.Image"), System.Drawing.Image)
        Me.PicIkan.Location = New System.Drawing.Point(305, 32)
        Me.PicIkan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicIkan.Name = "PicIkan"
        Me.PicIkan.Size = New System.Drawing.Size(122, 95)
        Me.PicIkan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicIkan.TabIndex = 24
        Me.PicIkan.TabStop = False
        '
        'GbMakanan
        '
        Me.GbMakanan.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.GbMakanan.Controls.Add(Me.LblBakso)
        Me.GbMakanan.Controls.Add(Me.LblIkan)
        Me.GbMakanan.Controls.Add(Me.LblAyam)
        Me.GbMakanan.Controls.Add(Me.LblKepiting)
        Me.GbMakanan.Controls.Add(Me.PicIkan)
        Me.GbMakanan.Controls.Add(Me.PicBakso)
        Me.GbMakanan.Controls.Add(Me.PicAyam)
        Me.GbMakanan.Controls.Add(Me.PicKepiting)
        Me.GbMakanan.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbMakanan.Location = New System.Drawing.Point(23, 79)
        Me.GbMakanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbMakanan.Name = "GbMakanan"
        Me.GbMakanan.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbMakanan.Size = New System.Drawing.Size(599, 175)
        Me.GbMakanan.TabIndex = 25
        Me.GbMakanan.TabStop = False
        Me.GbMakanan.Text = "Menu Terbaru"
        '
        'LblBakso
        '
        Me.LblBakso.AutoSize = True
        Me.LblBakso.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBakso.Location = New System.Drawing.Point(494, 140)
        Me.LblBakso.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblBakso.Name = "LblBakso"
        Me.LblBakso.Size = New System.Drawing.Size(47, 16)
        Me.LblBakso.TabIndex = 28
        Me.LblBakso.Text = "Bakso"
        '
        'LblIkan
        '
        Me.LblIkan.AutoSize = True
        Me.LblIkan.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIkan.Location = New System.Drawing.Point(326, 140)
        Me.LblIkan.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblIkan.Name = "LblIkan"
        Me.LblIkan.Size = New System.Drawing.Size(80, 16)
        Me.LblIkan.TabIndex = 27
        Me.LblIkan.Text = "Ikan Bakar"
        '
        'LblAyam
        '
        Me.LblAyam.AutoSize = True
        Me.LblAyam.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAyam.Location = New System.Drawing.Point(182, 140)
        Me.LblAyam.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblAyam.Name = "LblAyam"
        Me.LblAyam.Size = New System.Drawing.Size(90, 16)
        Me.LblAyam.TabIndex = 26
        Me.LblAyam.Text = "Ayam Bakar"
        '
        'LblKepiting
        '
        Me.LblKepiting.AutoSize = True
        Me.LblKepiting.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblKepiting.Location = New System.Drawing.Point(49, 140)
        Me.LblKepiting.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblKepiting.Name = "LblKepiting"
        Me.LblKepiting.Size = New System.Drawing.Size(62, 16)
        Me.LblKepiting.TabIndex = 25
        Me.LblKepiting.Text = "Kepiting"
        '
        'GbPemesanan
        '
        Me.GbPemesanan.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.GbPemesanan.Controls.Add(Me.TxtJmlBeli)
        Me.GbPemesanan.Controls.Add(Me.TxtHarga)
        Me.GbPemesanan.Controls.Add(Me.CmbJenis)
        Me.GbPemesanan.Controls.Add(Me.CmbNama)
        Me.GbPemesanan.Controls.Add(Me.LblJmlBeli)
        Me.GbPemesanan.Controls.Add(Me.LblHarga)
        Me.GbPemesanan.Controls.Add(Me.LblJenis)
        Me.GbPemesanan.Controls.Add(Me.LblNama)
        Me.GbPemesanan.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbPemesanan.Location = New System.Drawing.Point(23, 276)
        Me.GbPemesanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbPemesanan.Name = "GbPemesanan"
        Me.GbPemesanan.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbPemesanan.Size = New System.Drawing.Size(302, 163)
        Me.GbPemesanan.TabIndex = 26
        Me.GbPemesanan.TabStop = False
        Me.GbPemesanan.Text = "Pemesanan Makanan"
        '
        'GbPembayaran
        '
        Me.GbPembayaran.BackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.GbPembayaran.Controls.Add(Me.TxtTotalByr)
        Me.GbPembayaran.Controls.Add(Me.TxtDiskon)
        Me.GbPembayaran.Controls.Add(Me.TxtTotal)
        Me.GbPembayaran.Controls.Add(Me.LblTotalByr)
        Me.GbPembayaran.Controls.Add(Me.LblDiskon)
        Me.GbPembayaran.Controls.Add(Me.LblTotalharga)
        Me.GbPembayaran.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbPembayaran.Location = New System.Drawing.Point(338, 276)
        Me.GbPembayaran.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbPembayaran.Name = "GbPembayaran"
        Me.GbPembayaran.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GbPembayaran.Size = New System.Drawing.Size(283, 126)
        Me.GbPembayaran.TabIndex = 27
        Me.GbPembayaran.TabStop = False
        Me.GbPembayaran.Text = "Informasi Pembayaran"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(648, 530)
        Me.Controls.Add(Me.BtnBaru)
        Me.Controls.Add(Me.GbPembayaran)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GbPemesanan)
        Me.Controls.Add(Me.GbMakanan)
        Me.Controls.Add(Me.LblByMe)
        Me.Controls.Add(Me.BtnHitung)
        Me.Controls.Add(Me.LblKet)
        Me.Controls.Add(Me.LblJudul)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "Form1"
        Me.Text = "Aplikasi Pemesanan Makanan"
        CType(Me.PicKepiting, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicAyam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBakso, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicIkan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbMakanan.ResumeLayout(False)
        Me.GbMakanan.PerformLayout()
        Me.GbPemesanan.ResumeLayout(False)
        Me.GbPemesanan.PerformLayout()
        Me.GbPembayaran.ResumeLayout(False)
        Me.GbPembayaran.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblJudul As System.Windows.Forms.Label
    Friend WithEvents LblNama As System.Windows.Forms.Label
    Friend WithEvents LblJenis As System.Windows.Forms.Label
    Friend WithEvents LblHarga As System.Windows.Forms.Label
    Friend WithEvents LblJmlBeli As System.Windows.Forms.Label
    Friend WithEvents LblTotalharga As System.Windows.Forms.Label
    Friend WithEvents LblDiskon As System.Windows.Forms.Label
    Friend WithEvents LblTotalByr As System.Windows.Forms.Label
    Friend WithEvents LblKet As System.Windows.Forms.Label
    Friend WithEvents CmbNama As System.Windows.Forms.ComboBox
    Friend WithEvents CmbJenis As System.Windows.Forms.ComboBox
    Friend WithEvents TxtHarga As System.Windows.Forms.TextBox
    Friend WithEvents TxtJmlBeli As System.Windows.Forms.TextBox
    Friend WithEvents TxtTotal As System.Windows.Forms.TextBox
    Friend WithEvents TxtDiskon As System.Windows.Forms.TextBox
    Friend WithEvents TxtTotalByr As System.Windows.Forms.TextBox
    Friend WithEvents BtnHitung As System.Windows.Forms.Button
    Friend WithEvents BtnKeluar As System.Windows.Forms.Button
    Friend WithEvents BtnBaru As System.Windows.Forms.Button
    Friend WithEvents LblByMe As System.Windows.Forms.Label
    Friend WithEvents PicKepiting As System.Windows.Forms.PictureBox
    Friend WithEvents PicAyam As System.Windows.Forms.PictureBox
    Friend WithEvents PicBakso As System.Windows.Forms.PictureBox
    Friend WithEvents PicIkan As System.Windows.Forms.PictureBox
    Friend WithEvents GbMakanan As System.Windows.Forms.GroupBox
    Friend WithEvents LblBakso As System.Windows.Forms.Label
    Friend WithEvents LblIkan As System.Windows.Forms.Label
    Friend WithEvents LblAyam As System.Windows.Forms.Label
    Friend WithEvents LblKepiting As System.Windows.Forms.Label
    Friend WithEvents GbPemesanan As System.Windows.Forms.GroupBox
    Friend WithEvents GbPembayaran As System.Windows.Forms.GroupBox

End Class
