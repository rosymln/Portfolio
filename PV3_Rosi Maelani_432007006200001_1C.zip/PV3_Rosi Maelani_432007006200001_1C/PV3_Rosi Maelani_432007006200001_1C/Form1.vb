﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Pengisian untuk value cmbJabatan
        cmbJabatan.Items.Add("PNS")
        cmbJabatan.Items.Add("PPPK")
        cmbJabatan.Items.Add("THL")

        'Pengisian untuk value cmbGolongan
        cmbGolongan.Items.Add("1")
        cmbGolongan.Items.Add("2")
        cmbGolongan.Items.Add("3")

        txtGaji.Enabled = False
        txtGjBersih.Enabled = False
        txtTAnak.Enabled = False
        txtTIstri.Enabled = False
    End Sub

    Private Sub btnProses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProses.Click
        'Deklarasi Variabel
        Dim Jabatan, Jml_Anak As String
        Dim Golongan As Integer
        Dim Gaji, tnj_Istri, tnj_Anak, GjBersih, Pajak As Double
        Const pph As Decimal = 0.05

        Jabatan = cmbJabatan.Text
        Golongan = cmbGolongan.Text
        Jml_Anak = txtAnak.Text

        If (txtAnak.Text = "") Then
            Jml_Anak = 0
        End If

        If (cekMenikah.Checked = True) Then
            tnj_Istri = 200000
        Else
            tnj_Istri = 0
        End If

        'Percabangan
        If (Jabatan = "PNS") Then
            Select Case (Golongan)
                Case 1
                    Gaji = 2300000
                Case 2
                    Gaji = 2500000
                Case 3
                    Gaji = 3000000
                Case Else
                    Gaji = 0
                    MsgBox("Golongan Tidak Ada")
            End Select

        ElseIf (Jabatan = "PPPK") Then
            Select Case (Golongan)
                Case 1
                    Gaji = 1800000
                Case 2
                    Gaji = 2200000
                Case 3
                    Gaji = 2600000
                Case Else
                    Gaji = 0
                    MsgBox("Golongan Tidak Ada")
            End Select

        ElseIf (Jabatan = "THL") Then
            Select Case Golongan
                Case 1
                    Gaji = 1500000
                Case 2
                    Gaji = 1900000
                Case 3
                    Gaji = 2300000
                Case Else
                    Gaji = 0
            End Select
        Else
            MsgBox("Jabatan Tidak Ada")
        End If

        If (cekMenikah.Checked = True) And (Jml_Anak < 4) Then
            tnj_Anak = Jml_Anak * 150000
        ElseIf (cekMenikah.Checked = True) And (Jml_Anak >= 4) Then
            tnj_Anak = 450000
        Else
            tnj_Anak = 0
        End If

        txtTAnak.Text = tnj_Anak
        txtGaji.Text = Gaji
        txtTIstri.Text = tnj_Istri
        Pajak = Gaji * pph
        GjBersih = Gaji - Pajak + tnj_Anak + tnj_Istri
        txtGjBersih.Text = GjBersih
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        End
    End Sub

    Private Sub cekMenikah_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cekMenikah.CheckedChanged
        txtAnak.Enabled = True
    End Sub

    Private Sub cekBlmMenikah_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cekBlmMenikah.CheckedChanged
        txtAnak.Enabled = False
    End Sub

    Private Sub btnBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBaru.Click
        cmbGolongan.Text = ""
        cmbJabatan.Text = ""
        txtGaji.Text = ""
        txtAnak.Text = ""
        txtTIstri.Text = ""
        txtTAnak.Text = ""
        txtGjBersih.Text = ""
        cekMenikah.Checked = False
        cekBlmMenikah.Checked = False

    End Sub
End Class
