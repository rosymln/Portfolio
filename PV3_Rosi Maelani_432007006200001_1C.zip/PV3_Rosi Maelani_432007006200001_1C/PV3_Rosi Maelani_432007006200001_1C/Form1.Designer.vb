﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbJabatan = New System.Windows.Forms.ComboBox()
        Me.cmbGolongan = New System.Windows.Forms.ComboBox()
        Me.txtGaji = New System.Windows.Forms.TextBox()
        Me.btnProses = New System.Windows.Forms.Button()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.lblJabatan = New System.Windows.Forms.Label()
        Me.lblGolongan = New System.Windows.Forms.Label()
        Me.lblGaji = New System.Windows.Forms.Label()
        Me.lblJudul = New System.Windows.Forms.Label()
        Me.cekMenikah = New System.Windows.Forms.RadioButton()
        Me.cekBlmMenikah = New System.Windows.Forms.RadioButton()
        Me.lblJmlAnak = New System.Windows.Forms.Label()
        Me.lblTIstri = New System.Windows.Forms.Label()
        Me.lblTAnak = New System.Windows.Forms.Label()
        Me.lblPph = New System.Windows.Forms.Label()
        Me.lblGjBersih = New System.Windows.Forms.Label()
        Me.txtTAnak = New System.Windows.Forms.TextBox()
        Me.txtPph = New System.Windows.Forms.TextBox()
        Me.txtTIstri = New System.Windows.Forms.TextBox()
        Me.txtAnak = New System.Windows.Forms.TextBox()
        Me.txtGjBersih = New System.Windows.Forms.TextBox()
        Me.GBStatus = New System.Windows.Forms.GroupBox()
        Me.btnBaru = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GBStatus.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbJabatan
        '
        Me.cmbJabatan.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.cmbJabatan.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbJabatan.FormattingEnabled = True
        Me.cmbJabatan.Location = New System.Drawing.Point(101, 84)
        Me.cmbJabatan.Name = "cmbJabatan"
        Me.cmbJabatan.Size = New System.Drawing.Size(113, 23)
        Me.cmbJabatan.TabIndex = 0
        '
        'cmbGolongan
        '
        Me.cmbGolongan.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.cmbGolongan.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbGolongan.FormattingEnabled = True
        Me.cmbGolongan.Location = New System.Drawing.Point(101, 119)
        Me.cmbGolongan.Name = "cmbGolongan"
        Me.cmbGolongan.Size = New System.Drawing.Size(113, 23)
        Me.cmbGolongan.TabIndex = 1
        '
        'txtGaji
        '
        Me.txtGaji.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtGaji.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGaji.Location = New System.Drawing.Point(101, 152)
        Me.txtGaji.Name = "txtGaji"
        Me.txtGaji.Size = New System.Drawing.Size(113, 21)
        Me.txtGaji.TabIndex = 2
        '
        'btnProses
        '
        Me.btnProses.BackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnProses.Font = New System.Drawing.Font("Futura Md BT", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProses.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnProses.Location = New System.Drawing.Point(324, 221)
        Me.btnProses.Name = "btnProses"
        Me.btnProses.Size = New System.Drawing.Size(76, 31)
        Me.btnProses.TabIndex = 3
        Me.btnProses.Text = "Proses"
        Me.btnProses.UseVisualStyleBackColor = False
        '
        'btnKeluar
        '
        Me.btnKeluar.BackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnKeluar.Font = New System.Drawing.Font("Futura Md BT", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKeluar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnKeluar.Location = New System.Drawing.Point(379, 311)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(76, 31)
        Me.btnKeluar.TabIndex = 4
        Me.btnKeluar.Text = "Keluar"
        Me.btnKeluar.UseVisualStyleBackColor = False
        '
        'lblJabatan
        '
        Me.lblJabatan.AutoSize = True
        Me.lblJabatan.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJabatan.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblJabatan.Location = New System.Drawing.Point(22, 88)
        Me.lblJabatan.Name = "lblJabatan"
        Me.lblJabatan.Size = New System.Drawing.Size(50, 17)
        Me.lblJabatan.TabIndex = 5
        Me.lblJabatan.Text = "Jabatan"
        '
        'lblGolongan
        '
        Me.lblGolongan.AutoSize = True
        Me.lblGolongan.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGolongan.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblGolongan.Location = New System.Drawing.Point(22, 119)
        Me.lblGolongan.Name = "lblGolongan"
        Me.lblGolongan.Size = New System.Drawing.Size(60, 17)
        Me.lblGolongan.TabIndex = 6
        Me.lblGolongan.Text = "Golongan"
        '
        'lblGaji
        '
        Me.lblGaji.AutoSize = True
        Me.lblGaji.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGaji.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblGaji.Location = New System.Drawing.Point(22, 154)
        Me.lblGaji.Name = "lblGaji"
        Me.lblGaji.Size = New System.Drawing.Size(69, 17)
        Me.lblGaji.TabIndex = 7
        Me.lblGaji.Text = "Gaji Pokok"
        '
        'lblJudul
        '
        Me.lblJudul.AutoSize = True
        Me.lblJudul.Font = New System.Drawing.Font("Futura Md BT", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJudul.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblJudul.Location = New System.Drawing.Point(90, 14)
        Me.lblJudul.Name = "lblJudul"
        Me.lblJudul.Size = New System.Drawing.Size(319, 25)
        Me.lblJudul.TabIndex = 8
        Me.lblJudul.Text = "PROGRAM PERHITUNGAN GAJI"
        '
        'cekMenikah
        '
        Me.cekMenikah.AutoSize = True
        Me.cekMenikah.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cekMenikah.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cekMenikah.Location = New System.Drawing.Point(20, 29)
        Me.cekMenikah.Name = "cekMenikah"
        Me.cekMenikah.Size = New System.Drawing.Size(75, 21)
        Me.cekMenikah.TabIndex = 9
        Me.cekMenikah.TabStop = True
        Me.cekMenikah.Text = "Menikah"
        Me.cekMenikah.UseVisualStyleBackColor = True
        '
        'cekBlmMenikah
        '
        Me.cekBlmMenikah.AutoSize = True
        Me.cekBlmMenikah.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cekBlmMenikah.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cekBlmMenikah.Location = New System.Drawing.Point(20, 61)
        Me.cekBlmMenikah.Name = "cekBlmMenikah"
        Me.cekBlmMenikah.Size = New System.Drawing.Size(113, 21)
        Me.cekBlmMenikah.TabIndex = 10
        Me.cekBlmMenikah.TabStop = True
        Me.cekBlmMenikah.Text = "Belum Menikah"
        Me.cekBlmMenikah.UseVisualStyleBackColor = True
        '
        'lblJmlAnak
        '
        Me.lblJmlAnak.AutoSize = True
        Me.lblJmlAnak.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJmlAnak.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblJmlAnak.Location = New System.Drawing.Point(255, 88)
        Me.lblJmlAnak.Name = "lblJmlAnak"
        Me.lblJmlAnak.Size = New System.Drawing.Size(80, 17)
        Me.lblJmlAnak.TabIndex = 11
        Me.lblJmlAnak.Text = "Jumlah Anak"
        '
        'lblTIstri
        '
        Me.lblTIstri.AutoSize = True
        Me.lblTIstri.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTIstri.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTIstri.Location = New System.Drawing.Point(253, 120)
        Me.lblTIstri.Name = "lblTIstri"
        Me.lblTIstri.Size = New System.Drawing.Size(92, 17)
        Me.lblTIstri.TabIndex = 12
        Me.lblTIstri.Text = "Tunjangan Istri"
        '
        'lblTAnak
        '
        Me.lblTAnak.AutoSize = True
        Me.lblTAnak.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTAnak.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTAnak.Location = New System.Drawing.Point(253, 153)
        Me.lblTAnak.Name = "lblTAnak"
        Me.lblTAnak.Size = New System.Drawing.Size(101, 17)
        Me.lblTAnak.TabIndex = 13
        Me.lblTAnak.Text = "Tunjangan Anak"
        '
        'lblPph
        '
        Me.lblPph.AutoSize = True
        Me.lblPph.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPph.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblPph.Location = New System.Drawing.Point(253, 187)
        Me.lblPph.Name = "lblPph"
        Me.lblPph.Size = New System.Drawing.Size(30, 17)
        Me.lblPph.TabIndex = 14
        Me.lblPph.Text = "Pph"
        '
        'lblGjBersih
        '
        Me.lblGjBersih.AutoSize = True
        Me.lblGjBersih.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGjBersih.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblGjBersih.Location = New System.Drawing.Point(255, 267)
        Me.lblGjBersih.Name = "lblGjBersih"
        Me.lblGjBersih.Size = New System.Drawing.Size(70, 17)
        Me.lblGjBersih.TabIndex = 15
        Me.lblGjBersih.Text = "Gaji Bersih"
        '
        'txtTAnak
        '
        Me.txtTAnak.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtTAnak.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTAnak.Location = New System.Drawing.Point(362, 151)
        Me.txtTAnak.Name = "txtTAnak"
        Me.txtTAnak.Size = New System.Drawing.Size(113, 21)
        Me.txtTAnak.TabIndex = 16
        '
        'txtPph
        '
        Me.txtPph.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtPph.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPph.Location = New System.Drawing.Point(362, 184)
        Me.txtPph.Name = "txtPph"
        Me.txtPph.Size = New System.Drawing.Size(56, 21)
        Me.txtPph.TabIndex = 17
        Me.txtPph.Text = "5 %"
        Me.txtPph.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTIstri
        '
        Me.txtTIstri.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtTIstri.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTIstri.Location = New System.Drawing.Point(362, 118)
        Me.txtTIstri.Name = "txtTIstri"
        Me.txtTIstri.Size = New System.Drawing.Size(113, 21)
        Me.txtTIstri.TabIndex = 18
        '
        'txtAnak
        '
        Me.txtAnak.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtAnak.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAnak.Location = New System.Drawing.Point(362, 86)
        Me.txtAnak.Name = "txtAnak"
        Me.txtAnak.Size = New System.Drawing.Size(113, 21)
        Me.txtAnak.TabIndex = 19
        '
        'txtGjBersih
        '
        Me.txtGjBersih.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.txtGjBersih.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGjBersih.Location = New System.Drawing.Point(362, 267)
        Me.txtGjBersih.Name = "txtGjBersih"
        Me.txtGjBersih.Size = New System.Drawing.Size(113, 21)
        Me.txtGjBersih.TabIndex = 20
        '
        'GBStatus
        '
        Me.GBStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(201, Byte), Integer))
        Me.GBStatus.Controls.Add(Me.cekBlmMenikah)
        Me.GBStatus.Controls.Add(Me.cekMenikah)
        Me.GBStatus.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBStatus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GBStatus.Location = New System.Drawing.Point(25, 196)
        Me.GBStatus.Name = "GBStatus"
        Me.GBStatus.Size = New System.Drawing.Size(189, 99)
        Me.GBStatus.TabIndex = 21
        Me.GBStatus.TabStop = False
        Me.GBStatus.Text = "Status Pernikahan"
        '
        'btnBaru
        '
        Me.btnBaru.BackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnBaru.Font = New System.Drawing.Font("Futura Md BT", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBaru.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnBaru.Location = New System.Drawing.Point(268, 311)
        Me.btnBaru.Name = "btnBaru"
        Me.btnBaru.Size = New System.Drawing.Size(76, 31)
        Me.btnBaru.TabIndex = 22
        Me.btnBaru.Text = "Baru"
        Me.btnBaru.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Goudy Old Style", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(168, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 17)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Created by : Rosi Maelani"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(189, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(495, 360)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBaru)
        Me.Controls.Add(Me.GBStatus)
        Me.Controls.Add(Me.txtGjBersih)
        Me.Controls.Add(Me.txtAnak)
        Me.Controls.Add(Me.txtTIstri)
        Me.Controls.Add(Me.txtPph)
        Me.Controls.Add(Me.txtTAnak)
        Me.Controls.Add(Me.lblGjBersih)
        Me.Controls.Add(Me.lblPph)
        Me.Controls.Add(Me.lblTAnak)
        Me.Controls.Add(Me.lblTIstri)
        Me.Controls.Add(Me.lblJmlAnak)
        Me.Controls.Add(Me.lblJudul)
        Me.Controls.Add(Me.lblGaji)
        Me.Controls.Add(Me.lblGolongan)
        Me.Controls.Add(Me.lblJabatan)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.btnProses)
        Me.Controls.Add(Me.txtGaji)
        Me.Controls.Add(Me.cmbGolongan)
        Me.Controls.Add(Me.cmbJabatan)
        Me.Name = "Form1"
        Me.Text = "Perhitungan Gaji"
        Me.GBStatus.ResumeLayout(False)
        Me.GBStatus.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbJabatan As System.Windows.Forms.ComboBox
    Friend WithEvents cmbGolongan As System.Windows.Forms.ComboBox
    Friend WithEvents txtGaji As System.Windows.Forms.TextBox
    Friend WithEvents btnProses As System.Windows.Forms.Button
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents lblJabatan As System.Windows.Forms.Label
    Friend WithEvents lblGolongan As System.Windows.Forms.Label
    Friend WithEvents lblGaji As System.Windows.Forms.Label
    Friend WithEvents lblJudul As System.Windows.Forms.Label
    Friend WithEvents cekMenikah As System.Windows.Forms.RadioButton
    Friend WithEvents cekBlmMenikah As System.Windows.Forms.RadioButton
    Friend WithEvents lblJmlAnak As System.Windows.Forms.Label
    Friend WithEvents lblTIstri As System.Windows.Forms.Label
    Friend WithEvents lblTAnak As System.Windows.Forms.Label
    Friend WithEvents lblPph As System.Windows.Forms.Label
    Friend WithEvents lblGjBersih As System.Windows.Forms.Label
    Friend WithEvents txtTAnak As System.Windows.Forms.TextBox
    Friend WithEvents txtPph As System.Windows.Forms.TextBox
    Friend WithEvents txtTIstri As System.Windows.Forms.TextBox
    Friend WithEvents txtAnak As System.Windows.Forms.TextBox
    Friend WithEvents txtGjBersih As System.Windows.Forms.TextBox
    Friend WithEvents GBStatus As System.Windows.Forms.GroupBox
    Friend WithEvents btnBaru As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
